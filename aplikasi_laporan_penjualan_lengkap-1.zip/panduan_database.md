# Panduan Setup Database PostgreSQL

Aplikasi laporan penjualan ini menggunakan PostgreSQL sebagai basis data untuk menyimpan dan berbagi data penjualan antar perangkat. Berikut langkah-langkah untuk menyiapkan database:

## 1. Menginstal PostgreSQL

### Windows:
1. Download installer PostgreSQL dari [situs resmi PostgreSQL](https://www.postgresql.org/download/windows/)
2. Jalankan installer dan ikuti petunjuk instalasi
3. Ingat username, password, dan port yang diatur selama instalasi

### macOS:
1. Gunakan Homebrew: `brew install postgresql`
2. Atau download dari [situs resmi PostgreSQL](https://www.postgresql.org/download/macosx/)

### Linux (Ubuntu/Debian):
```
sudo apt update
sudo apt install postgresql postgresql-contrib
```

## 2. Membuat Database

Setelah PostgreSQL terinstal, buat database baru untuk aplikasi:

1. Buka command prompt/terminal
2. Login ke PostgreSQL:
   - Windows: `psql -U postgres`
   - Mac/Linux: `sudo -u postgres psql`
3. Buat database baru:
   ```sql
   CREATE DATABASE sales_app_db;
   ```
4. Verifikasi database telah dibuat:
   ```sql
   \l
   ```
5. Keluar dari PostgreSQL:
   ```sql
   \q
   ```

## 3. Menyiapkan Koneksi Database

1. Salin file `.env.example` menjadi `.env`:
   ```
   cp .env.example .env
   ```
2. Edit file `.env` dan ubah `DATABASE_URL` dengan kredensial database Anda:
   ```
   DATABASE_URL=postgres://username:password@hostname:port/database_name
   ```
   
   Contoh:
   ```
   DATABASE_URL=postgres://postgres:mypassword@localhost:5432/sales_app_db
   ```

## 4. Menjalankan Setup Database

Jalankan skrip setup untuk membuat tabel yang diperlukan:

```
python setup_database.py
```

Jika berhasil, pesan "Database berhasil diatur!" akan ditampilkan.

## 5. Menjalankan Aplikasi

Setelah database disiapkan, jalankan aplikasi:

```
streamlit run app.py
```

## Catatan Penting

- Pastikan PostgreSQL berjalan saat aplikasi dijalankan
- Database harus dapat diakses dari komputer yang menjalankan aplikasi
- Jika tidak ingin menggunakan database, gunakan versi lokal:
  ```
  streamlit run app_local.py
  ```